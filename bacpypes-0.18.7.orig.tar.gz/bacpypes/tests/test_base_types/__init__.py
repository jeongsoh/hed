#!/usr/bin/python

"""
Test Base Types Module
"""

from . import test_name_value

