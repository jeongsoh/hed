#!/usr/bin/python

"""
Test Local Schedule
"""

from . import test_local_schedule_1
from . import test_local_schedule_2

