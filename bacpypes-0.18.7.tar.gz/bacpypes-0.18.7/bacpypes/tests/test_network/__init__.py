#!/usr/bin/python

"""
Test Network Discovery
"""

from . import test_net_1
from . import test_net_2
from . import test_net_3
from . import test_net_4
from . import test_net_5
from . import test_net_6
from . import test_net_7

