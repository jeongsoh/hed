#!/usr/bin/python

"""
Test Constructed Data Module
"""

from . import test_sequence
from . import test_sequence_of
from . import test_array_of
from . import test_choice
from . import test_any
from . import test_any_atomic


